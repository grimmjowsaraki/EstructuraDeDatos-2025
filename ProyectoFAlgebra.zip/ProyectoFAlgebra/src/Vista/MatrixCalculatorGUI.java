/**
 *
 * @author Hongru Xiang
 */
//creditos al repositorio de https://github.com/orionHong/MatrixCalculator.git
package Vista;
import Controlador.MatrixCalculatorController;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.*;
import java.util.NoSuchElementException;

public class MatrixCalculatorGUI extends javax.swing.JFrame {

    private MatrixCalculatorController c;


    public MatrixCalculatorGUI() {
        initComponents();

        additionBt.setEnabled(false);
        subtractionBt.setEnabled(false);
        multiplicationBt.setEnabled(false);
        transposeABt.setEnabled(false);
        transposeBBt.setEnabled(false);
        result.setEditable(false);
        result.requestFocus();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFileChooser1 = new javax.swing.JFileChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        matrixAInput = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        matrixBInput = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        additionBt = new javax.swing.JButton();
        subtractionBt = new javax.swing.JButton();
        multiplicationBt = new javax.swing.JButton();
        transposeABt = new javax.swing.JButton();
        transposeBBt = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        matrixARowNum = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        matrixAColNum = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        matrixBRowNum = new javax.swing.JTextField();
        matrixBColNum = new javax.swing.JTextField();
        submitBt = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        result = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        ClearBt = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        filenameA = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        readFileA = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        readFileB = new javax.swing.JButton();
        filenameB = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Calculadora de Matriz"); // NOI18N

        matrixAInput.setColumns(20);
        matrixAInput.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        matrixAInput.setRows(5);
        matrixAInput.setText("0");
        jScrollPane1.setViewportView(matrixAInput);

        matrixBInput.setColumns(20);
        matrixBInput.setFont(new java.awt.Font("Monospaced", 0, 24)); // NOI18N
        matrixBInput.setRows(5);
        matrixBInput.setText("0");
        jScrollPane2.setViewportView(matrixBInput);

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 36)); // NOI18N
        jLabel1.setText("Matriz B");

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 36)); // NOI18N
        jLabel2.setText("Matriz A");

        additionBt.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        additionBt.setText("Suma");
        additionBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                additionBtActionPerformed(evt);
            }
        });

        subtractionBt.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        subtractionBt.setText("Resta");
        subtractionBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subtractionBtActionPerformed(evt);
            }
        });

        multiplicationBt.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        multiplicationBt.setText("Multiplicacion");
        multiplicationBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiplicationBtActionPerformed(evt);
            }
        });

        transposeABt.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        transposeABt.setText("Transponer [A]");
        transposeABt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transposeABtActionPerformed(evt);
            }
        });

        transposeBBt.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        transposeBBt.setText("Transponer[B]");
        transposeBBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transposeBBtActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("Numero de Filas: ");

        matrixARowNum.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        matrixARowNum.setText("1");
        matrixARowNum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                matrixARowNumFocusGained(evt);
            }
        });
        matrixARowNum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                matrixARowNumKeyReleased(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setText("Numero de Columnas: ");

        matrixAColNum.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        matrixAColNum.setText("1");
        matrixAColNum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                matrixAColNumFocusGained(evt);
            }
        });
        matrixAColNum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                matrixAColNumKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel5.setText("Numero de filas: ");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setText("Numero de columnas: ");

        matrixBRowNum.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        matrixBRowNum.setText("1");
        matrixBRowNum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                matrixBRowNumFocusGained(evt);
            }
        });
        matrixBRowNum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                matrixBRowNumKeyReleased(evt);
            }
        });

        matrixBColNum.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        matrixBColNum.setText("1");
        matrixBColNum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                matrixBColNumFocusGained(evt);
            }
        });
        matrixBColNum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                matrixBColNumKeyReleased(evt);
            }
        });

        submitBt.setFont(new java.awt.Font("Calibri", 0, 30)); // NOI18N
        submitBt.setText("Probar");
        submitBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtActionPerformed(evt);
            }
        });

        result.setColumns(20);
        result.setFont(new java.awt.Font("Monospaced", 1, 36)); // NOI18N
        result.setRows(5);
        jScrollPane3.setViewportView(result);

        jLabel7.setFont(new java.awt.Font("Calibri", 0, 36)); // NOI18N
        jLabel7.setText("Resultado");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Mateo Garcia Fatima Lissbeth", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 24))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel8.setText("Matriz Calculadora");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap(111, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addGap(103, 103, 103))
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(jLabel8)
                                .addContainerGap(29, Short.MAX_VALUE))
        );

        ClearBt.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        ClearBt.setText("Limpiar");
        ClearBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearBtActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Read from file", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 24))); // NOI18N

        filenameA.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel9.setText(".txt");

        readFileA.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        readFileA.setText("Leer Matriz A");
        readFileA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readFileAActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel10.setText(".txt");

        readFileB.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        readFileB.setText("Leer Matriz B");
        readFileB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readFileBActionPerformed(evt);
            }
        });

        filenameB.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(filenameA, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(filenameB, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel10)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(readFileB, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(readFileA, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(readFileB))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(11, 11, 11)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(filenameA, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel9)
                                                        .addComponent(readFileA))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(jLabel10)
                                                                .addGap(0, 0, Short.MAX_VALUE))
                                                        .addComponent(filenameB, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE))))
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(141, 141, 141)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(32, 32, 32)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)))
                                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                                                .addGap(1, 1, 1)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(matrixARowNum, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(matrixAColNum, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(matrixBRowNum)
                                                        .addComponent(matrixBColNum, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addComponent(jScrollPane2)
                                        .addComponent(jScrollPane1))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(40, 40, 40)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(transposeABt, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGroup(layout.createSequentialGroup()
                                                                                .addComponent(submitBt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addGap(38, 38, 38)
                                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                                        .addComponent(additionBt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                                        .addComponent(subtractionBt, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)))))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(transposeBBt, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(multiplicationBt, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(105, 105, 105)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGroup(layout.createSequentialGroup()
                                                                                .addGap(342, 342, 342)
                                                                                .addComponent(ClearBt, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(72, 72, 72))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(85, 85, 85))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel7)
                                                .addGap(324, 324, 324))))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(66, 66, 66)
                                                .addComponent(jLabel2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel3)
                                                        .addComponent(matrixARowNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(1, 1, 1)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                                        .addComponent(jLabel4)
                                                                        .addComponent(matrixAColNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(jLabel1)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                                        .addComponent(matrixBRowNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(jLabel5))
                                                                .addGap(1, 1, 1)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jLabel6)
                                                                        .addComponent(matrixBColNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(12, 12, 12))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(12, 12, 12)
                                                                .addComponent(transposeABt, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(128, 128, 128)
                                                                .addComponent(additionBt, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(9, 9, 9)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                                        .addComponent(subtractionBt, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(submitBt, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(multiplicationBt, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                                                                .addComponent(transposeBBt, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(77, 77, 77))
                                        .addGroup(layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(23, 23, 23)
                                                .addComponent(ClearBt, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(41, 41, 41)
                                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(31, 31, 31))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void transposeABtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transposeABtActionPerformed
        // To transpose Matrix A and make it appear in Matrix A text area
        c.transposeA();
        matrixAInput.setText(c.toStringA());

        String temp = matrixARowNum.getText();
        matrixARowNum.setText(matrixAColNum.getText());
        matrixAColNum.setText(temp);

        verify();
    }//GEN-LAST:event_transposeABtActionPerformed

    private void additionBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_additionBtActionPerformed
        // Do addition and make it appear in result text area
        c.addition();
        result.setText(c.toStringResult());
    }//GEN-LAST:event_additionBtActionPerformed

    private void subtractionBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subtractionBtActionPerformed
        // Do subtraction and make it appear in result text area
        c.subtraction();
        result.setText(c.toStringResult());
    }//GEN-LAST:event_subtractionBtActionPerformed

    private void submitBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtActionPerformed
        // Submit matrix property to controller
        String matrixAString = matrixAInput.getText();
        String matrixBString = matrixBInput.getText();

        try{
            int matrixARow = Integer.parseInt(matrixARowNum.getText());
            int matrixACol = Integer.parseInt(matrixAColNum.getText());
            int matrixBRow = Integer.parseInt(matrixBRowNum.getText());
            int matrixBCol = Integer.parseInt(matrixBColNum.getText());

            c.addMatrixA(getIntArray(matrixAString, matrixARow, matrixACol));
            c.addMatrixB(getIntArray(matrixBString, matrixBRow, matrixBCol));

            verify();
        }
        catch(NumberFormatException ex) {
            displayErrorMessage("Debes ingresar un número entero positivo");
        }



        // Verification.


    }//GEN-LAST:event_submitBtActionPerformed

    private void transposeBBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transposeBBtActionPerformed
        // Do transpose, and make it appear in the Matrix B text area
        c.transposeB();

        matrixBInput.setText(c.toStringB());

        String temp = matrixBRowNum.getText();
        matrixBRowNum.setText(matrixBColNum.getText());
        matrixBColNum.setText(temp);

        verify();
    }//GEN-LAST:event_transposeBBtActionPerformed

    private void ClearBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearBtActionPerformed
        // Reset the property
        reset();
        c.reset();
    }//GEN-LAST:event_ClearBtActionPerformed

    private void multiplicationBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiplicationBtActionPerformed
        // Do multilication, and make it appear in resutl text area
        c.multiplication();
        result.setText(c.toStringResult());
    }//GEN-LAST:event_multiplicationBtActionPerformed

    private void readFileAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readFileAActionPerformed
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new File("C:\\Users\\Xiang Hongru\\Documents"
                + "\\NetBeansProjects\\MatrixCalculator-Orion\\MatrixFiles"));
        fc.setDialogTitle("Leer archivo.txt de Matriz A");
        fc.showOpenDialog(null);

        try{
            Scanner input = new Scanner(fc.getSelectedFile());

            try{
                try{
                    int rowNum = input.nextInt();
                    int colNum = input.nextInt();


                    String s = "";

                    while(input.hasNext()) {
                        s += input.nextLine() + " ";
                    }

                    c.addMatrixA(getIntArray(s, rowNum, colNum));
                }
                catch(java.util.InputMismatchException ex) {
                    displayErrorMessage("Error de archivo");
                }
            }
            catch(IndexOutOfBoundsException ex) {
                displayErrorMessage("File Error\n" +
                        "Format for file:\n Row number Column number \n "
                        + "Matrix data\n"
                        + "(Only one matrix required)");
            }

            showMatrix();
        }
        catch(FileNotFoundException ex) {
            displayErrorMessage("Archivo no encontrado");
        }

        filenameA.setText(fc.getSelectedFile().getAbsolutePath());


    }//GEN-LAST:event_readFileAActionPerformed

    private void readFileBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readFileBActionPerformed
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new File("C:\\Users\\Xiang Hongru\\Documents"
                + "\\NetBeansProjects\\MatrixCalculator-Orion\\MatrixFiles"));
        fc.setDialogTitle("Leer archivo.txt de matriz b");
        fc.showOpenDialog(null);

        try{
            Scanner input = new Scanner(fc.getSelectedFile());

            try{
                try{
                    int rowNum = input.nextInt();
                    int colNum = input.nextInt();


                    String s = "";

                    while(input.hasNext()) {
                        s += input.nextLine() + " ";
                    }

                    c.addMatrixB(getIntArray(s, rowNum, colNum));
                }
                catch(java.util.InputMismatchException ex) {
                    displayErrorMessage("Error en el archivo");
                }
            }
            catch(IndexOutOfBoundsException ex) {
                displayErrorMessage("File Error\n" +
                        "Format for file:\n Row number Column number \n "
                        + "Matrix data\n"
                        + "(Only one matrix required)");
            }

            showMatrix();
        }
        catch(FileNotFoundException ex) {
            displayErrorMessage("Archivo no encontrado");
        }

        filenameB.setText(fc.getSelectedFile().getAbsolutePath());


    }//GEN-LAST:event_readFileBActionPerformed

    private void matrixARowNumKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_matrixARowNumKeyReleased
        StringBuilder s = new StringBuilder(matrixARowNum.getText());

        deleteNonDigit(s, matrixARowNum);
    }//GEN-LAST:event_matrixARowNumKeyReleased

    private void matrixAColNumKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_matrixAColNumKeyReleased
        StringBuilder s = new StringBuilder(matrixAColNum.getText());

        deleteNonDigit(s, matrixAColNum);
    }//GEN-LAST:event_matrixAColNumKeyReleased

    private void matrixBRowNumKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_matrixBRowNumKeyReleased
        StringBuilder s = new StringBuilder(matrixBRowNum.getText());

        deleteNonDigit(s, matrixBRowNum);
    }//GEN-LAST:event_matrixBRowNumKeyReleased

    private void matrixBColNumKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_matrixBColNumKeyReleased
        StringBuilder s = new StringBuilder(matrixBColNum.getText());

        deleteNonDigit(s, matrixBColNum);
    }//GEN-LAST:event_matrixBColNumKeyReleased

    private void matrixAColNumFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_matrixAColNumFocusGained
        matrixAColNum.setText("");
    }//GEN-LAST:event_matrixAColNumFocusGained

    private void matrixBRowNumFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_matrixBRowNumFocusGained
        matrixBRowNum.setText("");
    }//GEN-LAST:event_matrixBRowNumFocusGained

    private void matrixBColNumFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_matrixBColNumFocusGained
        matrixBColNum.setText("");
    }//GEN-LAST:event_matrixBColNumFocusGained

    private void matrixARowNumFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_matrixARowNumFocusGained
        matrixARowNum.setText("");
    }//GEN-LAST:event_matrixARowNumFocusGained

    /*** To convert String into int[][] **/
    public int[][] getIntArray(String matrixString, int row, int col){
        Scanner input = new Scanner(matrixString);
        int[][] m = new int[0][0];
        try{
            m = new int[row][col];
        }
        catch(NegativeArraySizeException ex) {
            displayErrorMessage("Debes ingresar un número entero positivo en "
                    + "filas y columnas");
        }

        try{
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    m[i][j] = input.nextInt();
                }
            }
            if (input.hasNext())
                displayErrorMessage("Matriz es incorrecta");
        }
        catch(NoSuchElementException ex) {
            displayErrorMessage("Debes ingresar la matriz correcta");
        }

        return m;
    }

    /** To display an error message ***/
    void displayErrorMessage(String errorMessage) {
        JOptionPane.showMessageDialog(this, errorMessage);
    }

    //** Reset the property in MatrixCalculatorGUI ***/
    private void reset(){
        additionBt.setEnabled(false);
        subtractionBt.setEnabled(false);
        multiplicationBt.setEnabled(false);
        transposeABt.setEnabled(false);
        transposeBBt.setEnabled(false);

        matrixARowNum.setText("1");
        matrixAColNum.setText("1");
        matrixBRowNum.setText("1");
        matrixBColNum.setText("1");

        matrixAInput.setText("0");
        matrixBInput.setText("0");
        result.setText("");

        matrixARowNum.requestFocus();
    }

    /*** To verify the eligibility of doing a calculation
     * before disabling all the buttons
     * **/
    void verify(){
        additionBt.setEnabled(false);
        subtractionBt.setEnabled(false);
        multiplicationBt.setEnabled(false);
        transposeABt.setEnabled(false);
        transposeBBt.setEnabled(false);

        if(c.isLegalToAddAndSubract()){
            additionBt.setEnabled(true);
            subtractionBt.setEnabled(true);
        }
        if(c.isLegalForMulti()){
            multiplicationBt.setEnabled(true);
        }

        transposeABt.setEnabled(true);
        transposeBBt.setEnabled(true);
    }

    /*** To show the stage ***/
    public void showMatrix(){
        matrixARowNum.setText(c.getARowNum());
        matrixAColNum.setText(c.getAColNum());
        matrixBRowNum.setText(c.getBRowNum());
        matrixBColNum.setText(c.getBColNum());

        matrixAInput.setText(c.toStringA());
        matrixBInput.setText(c.toStringB());
    }

    public void deleteNonDigit(StringBuilder s, JTextField tf){
        for(int i = 0; i < s.length(); i++) {
            if(!Character.isDigit(s.charAt(i))) {
                s.deleteCharAt(i);
            }
        }
        tf.setText(s.toString());
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MatrixCalculatorGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MatrixCalculatorGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MatrixCalculatorGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MatrixCalculatorGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MatrixCalculatorGUI().setVisible(true);
            }
        });
        */
    }

    /** To add controller ***/
    public void addController(MatrixCalculatorController c) {
        this.c = c;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ClearBt;
    private javax.swing.JButton additionBt;
    private javax.swing.JTextField filenameA;
    private javax.swing.JTextField filenameB;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField matrixAColNum;
    private javax.swing.JTextArea matrixAInput;
    private javax.swing.JTextField matrixARowNum;
    private javax.swing.JTextField matrixBColNum;
    private javax.swing.JTextArea matrixBInput;
    private javax.swing.JTextField matrixBRowNum;
    private javax.swing.JButton multiplicationBt;
    private javax.swing.JButton readFileA;
    private javax.swing.JButton readFileB;
    private javax.swing.JTextArea result;
    private javax.swing.JButton submitBt;
    private javax.swing.JButton subtractionBt;
    private javax.swing.JButton transposeABt;
    private javax.swing.JButton transposeBBt;
    // End of variables declaration//GEN-END:variables
}
